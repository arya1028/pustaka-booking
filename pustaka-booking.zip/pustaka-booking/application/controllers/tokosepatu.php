<?php
class TokoSepatu extends CI_Controller
{

    public function index()

}
{
    $this->load->view('view-tokosepatu');
   
    public function cetak()

}

public function cetak()
{
    $data=[
        ''=> $this->input->post(''),
        ''=> $this->input->post(''),
        ''=> $this->input->post('')

    ];
 
    $this->load->view ('view-tokosepatu',$data);
];
$this->load->input('view-tokosepatu' $Data);

}
}
