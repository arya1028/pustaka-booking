<?php
class Contoh1 extends CI_Controller
{
  public function index()
  {
      echo "<h1>Perkenalan</h1>";
      echo"Nama Saya Afria Pratama
           Saya Tinggal di Daerah Pasar Minggu
           Olah Raga yang saya sukai adalah 
           Futsal";
  }

}