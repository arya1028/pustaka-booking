<html>
<head>
	<title>Form Input Transaksi</title>
</head>

<body>
	<center>
		<form action="<?= base_url('index.php/transaksi/cetak'); ?>" method="post">
		<table>
		<tr>
			<th colspan="3">
				Form Input Data Transaksi
			</th>
		</tr>
		<tr>                     
			<td colspan="3">                         
				<hr>  
			</td>
		<tr>
			<th>Kode TNK</th>
			<th>:</th>
			<td>
				<input type="text" name="kode" id="kode">
			</td>
		<tr>
            <th>No. HP</th>
            <th>:</th>
            <td>
               <input type="text" name="nohp" id="nohp">
            </td>
        </tr>
        <tr>
            <th>Merk Sepatu</th>
            <td>:</td>
            <td>
                <select name="merk" id="merk">
                    <option value="">Pilih Merk</option>
                    <option value="Nike Rp.375.000">Nike</option>
                    <option value="Adidas Rp.300.000">Adidas</option>
                    <option value="Kickers Rp.250.000">Kickers</option>
                    <option value="Eiger Rp.275.000">Eiger</option>
                    <option value="Bucherri Rp.400.000">Bucherri</option>
                </select>
            </td>
        </tr>
        <tr>
            <th>No. Sepatu</th>
            <td>:</td>
            <td>
               <select name="nospt" id="nospt">
                   <option value="">Pilih Nomer Sepatu</option>

                   <?php
                   // Looping Nomer Sepatu
                      $nospt = 32;
                      do { ?>
                          <option value="<?= $nospt; ?>"><?= $nospt; ?></option>
                    <?php
                           $nospt++;
                         } while ($nospt <= 44);
                    ?>
                </select>
             </td>
        </tr>
        <tr>
           <td colspan="3" align="center">
				<input type="submit" name="submit">
			</td>
		</tr>
	</table>
	</form>
	</center>
</body>
</html>