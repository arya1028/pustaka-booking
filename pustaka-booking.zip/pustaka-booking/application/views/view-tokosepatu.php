<html>

<head>
  <title>Form Toko Sepatu Online </title>
  </head>

  <body>
       <center>
              <form   action="<?=   base_url('matakuliah/cetak');    ?>"
              method="post">
                      <table>
                      <tr>
                          <th colspan="3">
                             Form Toko Sepatu Sport
                            </th>
                            </tr>
                            <tr>
                                  <td colspan="3">
                                     <hr>
                                </td>
                           </tr>
                        <tr>
                             <th>          </th>
                             <th>:</th>
                             <td>
                                <input type="text" name="kode" id="kode">
                                </td>
                                </tr>
                                <tr>
                                    <th>      </th>
                                    <td>:</td>
                                    <td>
                                          <input type="text" name="nama" id="kode">
                                    </td>
                                    <tr>
                                          <th>   </th>
                                          <td>:</td>
                                          <td>
                                          <select name="" id="">
                                          <option value="">pilih   </option>
                                          <option value=""></option>
                                          <option value=""></option>
                                          <option value=""></option>

                                          </select>
                                          </td>
                                          </tr>
                                          <tr>
                                                 <td colspan="3" align="center">
                                                    <input type="submit" value="submit">
                                                    </td>
                                                    </tr>
                                                    </table>
                                                    </form>
                                                    </center>
                                                    </body>

                                                    </html>