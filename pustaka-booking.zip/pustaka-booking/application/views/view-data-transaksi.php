<html> 
 
<head>     
	<title>Tampil Data Transaksi</title> 
</head> 
 
<body>     
	<center>         
		<table>             
			<tr>                
				<th colspan="3">     
			     Tampil Data Transaksi                 
			 	</th>             
			</tr>
            <tr>
               <th>Merk Sepatu</th>
               <th>:</th>
               <td>
                  <?= $ex_merk[0]; ?>
               </td>
            </tr>
            <tr>
               <th>Harga Sepatu</th>
               <th>:</th>
               <td>
                  <?= $ex_merk[1]; ?>
               </td>
            </tr>
            <tr>
               <th>Nomer Sepatu</th>
               <th>:</th>
               <td>
                  <?= $nospt; ?>
               </td>
            </tr>
            <tr>
               <td colspan=3 align="center">
                   <a href="<?= base_url('Transaksi'); ?>">Kembali</a>
               </td>             
			</tr>         
		</table>     
	</center> 
</body> 
 
</html> 